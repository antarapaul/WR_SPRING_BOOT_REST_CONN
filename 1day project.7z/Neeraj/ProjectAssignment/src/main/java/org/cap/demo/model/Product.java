package org.cap.demo.model;

import java.io.Serializable;
import java.sql.Date;

public class Product implements Serializable{


	private Integer productId;
	private String productName;
	private String description;
	private Date expiryDate;
	private String quantity;
	private String category;
	private double price;
	
	
	private byte[] image;

	public Product() {
		
	}

	public Product(Integer productId, String productName, String description, Date expiryDate, String quantity,
			String category, double price, byte[] image) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.quantity = quantity;
		this.category = category;
		this.price = price;
		this.image = image;
	}

	public Product(String productName, String description, Date expiryDate, String quantity, String category,
			double price, byte[] image) {
		super();
		this.productName = productName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.quantity = quantity;
		this.category = category;
		this.price = price;
		this.image = image;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "Product [productName=" + productName + ", description=" + description + ", expiryDate=" + expiryDate
				+ ", quantity=" + quantity + ", category=" + category + ", price=" + price + ", image=" + image + "]";
	}

}
