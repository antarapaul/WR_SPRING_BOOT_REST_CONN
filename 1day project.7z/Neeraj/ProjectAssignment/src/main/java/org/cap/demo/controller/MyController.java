package org.cap.demo.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.cap.demo.model.Product;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class MyController {

	

	@PostMapping("/saveProduct")
	public ResponseEntity<Product[]> addProductPage(@Valid @ModelAttribute ("product")Product product,BindingResult result) {
		System.out.println("Post");
		RestTemplate restTemplate=new RestTemplate();
		
		//Product[] products= restTemplate.getForObject("http://localhost:8082/api/products", Product[].class);
		ResponseEntity<Product[]> products= restTemplate.postForEntity("http://localhost:8081/products",product, Product[].class);
		
         //Product product=productdao.save(product);
		System.out.println(products);
		//return new ResponseEntity<Product[]>(products, HttpStatus.OK);
		return new ResponseEntity<Product[]>(HttpStatus.OK);
	} 
 

			
			
	@DeleteMapping("/delete/{productId}")
	public String deletePilot(@PathVariable("productId") Integer productId) {

	final String uri="http://localhost:8081/products"+productId;
    RestTemplate restTemplate=new RestTemplate();

	java.util.Map<String, Object> params=new HashMap<>();
	params.put("productId", productId);


	restTemplate.delete(uri,params);

	return "index";
	
	}	  

	@RequestMapping("/listproduct")
	public String getProducts(ModelMap map) {
		String url="http://localhost:8081/products";
		RestTemplate restTemplate=new RestTemplate();
		Product[] products=restTemplate.getForObject(url, Product[].class);
		map.put("product", new Product());
		map.put("products",products);
		return "/";
	} 
 

	
	
}
