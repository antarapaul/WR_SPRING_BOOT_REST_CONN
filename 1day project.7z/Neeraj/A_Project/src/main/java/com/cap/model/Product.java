package com.cap.model;


import java.sql.Date;
import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Product {
	

	@Id
	private Integer productId;
	private String productName;
	private String description;
	private String catagory;
	private byte[] image;
	private Integer quantity;
	private Double price;
	
	private Date expiryDate;
	
	public Product() {
		
	}

	public Product(Integer productId, String productName, String description, String catagory, byte[] image,
			Integer quantity, Double price, Date expiryDate) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.catagory = catagory;
		this.image = image;
		this.quantity = quantity;
		this.price = price;
		this.expiryDate = expiryDate;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCatagory() {
		return catagory;
	}

	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", description=" + description
				+ ", catagory=" + catagory + ", image=" + Arrays.toString(image) + ", quantity=" + quantity + ", price="
				+ price + ", expiryDate=" + expiryDate + "]";
	}

	
	
	
	

}
