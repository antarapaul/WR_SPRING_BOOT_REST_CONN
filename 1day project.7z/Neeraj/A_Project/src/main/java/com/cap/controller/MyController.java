package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cap.dao.IPDao;
import com.cap.model.Product;
import com.cap.service.IPService;



@RestController
public class MyController {
	
	@Autowired
	private IPService pService;
	@Autowired
	private IPDao pDao;
	
	
	@GetMapping("/products/{input}")
	 public ResponseEntity<List<Product>> findProduct(@PathVariable("input") String input){
			List<Product> products=pDao.findProduct(input);
			/*System.out.println(products);*/
			if(products.isEmpty()) {
				return new ResponseEntity("Sorry No Products Found..",HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
			
		} 
	
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProduct() {
		
		List<Product> products = pService.getAllProducts();
		
		if(products.isEmpty())
			return new ResponseEntity("Sorry! no products found",HttpStatus.OK);
		
		return new ResponseEntity <List<Product>>(products,HttpStatus.OK);
		
	} 
	
	
	
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> saveProduct(@RequestBody Product product){
		List<Product> products=pService.saveProduct(product);
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry No Products Found..",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(
			@PathVariable("productId")Integer productId){
		List<Product> products= pService.deleteProduct(productId);
		if(products.isEmpty() || products==null) {
			return new ResponseEntity("Sorry! ProductsId not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}	
	
	
	@PutMapping("/products")
	public ResponseEntity<List<Product>> updateProduct(
			@RequestBody Product product){
		List<Product> products= pService.updateProduct(product);
		if(products.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
	
	
	/*@GetMapping("/findById")
	public ResponseEntity<List<Product>> getAllProductsById(
			@RequestParam("productId") Integer productId
			@PathVariable("productId")Integer productId){
		List<Product> products= pService.findByProductId(productId);
		if(products.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
	@GetMapping("/findByName")
	public ResponseEntity<List<Product>> getAllProductsByName(
			@RequestParam("productName") String productName
			@PathVariable("productName")String productName){
		List<Product> products= pService.findByProductName(productName);
		if(products.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	

	@GetMapping("/findByCatagory")
	public ResponseEntity<List<Product>> getAllProductsByCatagory(
			@RequestParam("catagory") String catagory
			@PathVariable("catagory")String catagory){
		List<Product> products= pService.findByCatagory(catagory);
		if(products.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	

	@GetMapping("/findByPrice")
	public ResponseEntity<List<Product>> getAllProductsByPrice(
			@RequestParam("price") double price
			@PathVariable("price")Double price){
		List<Product> products= pService.findByPrice(price);
		if(products.isEmpty())
			return new ResponseEntity(
					"Sorry! Pilots info not available", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	*/
	

}
