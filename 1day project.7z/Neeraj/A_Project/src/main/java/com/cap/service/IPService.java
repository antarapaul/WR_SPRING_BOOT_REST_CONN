package com.cap.service;

import java.util.List;

import com.cap.model.Category;
import com.cap.model.Product;

public interface IPService {
	/*
	public List<Product> findByProductId(Integer productId);

	public List<Product> findByProductName(String productName);
	
	public List<Product> findByCatagory(String catagory);
	
	public List<Product> findByPrice(Double price);*/

	public List<Product> saveProduct(Product product);

	public List<Product> getAllProducts();

	public List<Product> deleteProduct(Integer productId);

	public List<Product> updateProduct(Product product);
	
	
	//public void saveProduct(Product product);

	public List<Category> getAllCategory();

	//public List<Product> getAllProducts();

	

}
