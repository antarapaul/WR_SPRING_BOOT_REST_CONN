package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.ICategoryDao;
import com.cap.dao.IPDao;
import com.cap.model.Category;
import com.cap.model.Product;

@Service("pService")
public class PServiceImpl implements IPService{
	
	@Autowired
	private IPDao pDao;
	@Autowired
	private ICategoryDao categoryDao;

	

	/*@Override
	public List<Product> findByCatagory(String catagory) {
		// TODO Auto-generated method stub
		return pDao.findById(catagory);
	}

	

	@Override
	public List<Product> findByProductId(Integer productId) {
		// TODO Auto-generated method stub
		return pDao.findByProductId(productId);
	}

	@Override
	public List<Product> findByProductName(String productName) {
		// TODO Auto-generated method stub
		return pDao.findByProductName(productName);
	}



	@Override
	public List<Product> findByPrice(Double price) {
		// TODO Auto-generated method stub
		return pDao.findByPrice(price);
	}*/



	@Override
	public List<Product> saveProduct(Product product) {
		pDao.save(product);
		return pDao.findAll();
	}



	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return pDao.findAll();
	}



	@Override
	public List<Product> deleteProduct(Integer productId) {
		pDao.deleteById(productId);
		return pDao.findAll();
	}



	@Override
	public List<Product> updateProduct(Product product) {
		if(product!=null) {
			pDao.save(product);
		}
		return pDao.findAll();
	}
	
	/*@Override
	public void saveProduct(Product product) {
		
		productDao.save(product);
		
	}*/

	@Override
	public List<Category> getAllCategory() {
		
		return categoryDao.findAll();
	}

	/*@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}
*/

	

}
